Sarsa Lambda Fourier Basis (Java)
-------------------------------
For full details about how to use this project, its history, and how to get help, please visit:
http://library.rl-community.org/wiki/Sarsa_Lambda_Fourier_Basis_(Java)
